import json
import tkinter as tk
import sys
from tkinter import simpledialog

def read_tokens(file_name="lexical.txt"):
    """Read tokens from the tokenizer output file."""
    tokens = []

    try:
        with open(file_name, "r") as token_file:
            for line in token_file:
                token = json.loads(line.strip())
                tokens.append(token)
        
        return tokens
    except FileNotFoundError:
        print(f"Error: {file_name} not found.", flush=True)
        return []
    except json.JSONDecodeError as e:
        print(f"Error decoding JSON: {e}", flush=True)
        return []
    
class Parser:
    def __init__(self, tokens, input_callback=None):
        self.tokens = tokens
        self.current = 0
        self.it = None
        self.variables = {}         # Store variable values
        self.symbol_table = {}      # Store symbol table entries
        self.output = []            # Capture output lines
        self.inside_wazzup = False
        self.functions = {}         # Store function definitions
        self.input_callback = input_callback  # Callback for inputs

    def peek(self):
        """Peek at the current token."""
        while self.current < len(self.tokens):
            token = self.tokens[self.current]
            if token["type"] == "COMMENT":
                # Skip over COMMENT tokens
                self.current += 1
                continue
            return token
        return None

    def consume(self):
        """Consume and return the current token."""
        token = self.peek()
        if token:
            self.current += 1
        return token

    def match(self, expected_type, expected_value=None):
        """Match the current token against an expected type and value."""
        token = self.peek()
        if token and token["type"] == expected_type and (expected_value is None or token["value"] == expected_value):
            return self.consume()
        return None

    def error(self, message):
        """Raise a syntax error."""
        token = self.peek()
        position = self.current
        if token:
            raise SyntaxError(f"{message}. Found {token} at position {position}.")
        else:
            raise SyntaxError(f"{message}. Reached end of input.")

    def parse_literal(self):
        """Parse a literal: numbr, numbar, yarn, troof."""
        # check for TROOF literal (WIN or FAIL)
        troof = self.match("TROOF_LITERAL")
        if troof:
            if troof["value"] == "WIN":
                self.it = True 
            elif troof["value"] == "FAIL":
                self.it = False
            return troof

        """Parse a literal value: NUMBR, NUMBAR, YARN, TROOF."""
        if self.match("NUMBR_LITERAL"):
            return {"type": "NUMBR", "value": int(self.tokens[self.current - 1]["value"])}
        elif self.match("NUMBAR_LITERAL"):
            return {"type": "NUMBAR", "value": float(self.tokens[self.current - 1]["value"])}
        elif self.match("YARN_LITERAL"):
            return {"type": "YARN", "value": self.tokens[self.current - 1]["value"]}
        elif self.match("TROOF_LITERAL"):
            return {"type": "TROOF", "value": self.tokens[self.current - 1]["value"] == "WIN"}

        return None
        
    def parse_expression(self):
        """Parse an expression: arithmetic, logical, literal, or variable."""
        # Parse first operand
        if not self.parse_operand():
            self.error("Expected operand")
        
        result = self.it
        
        # Check for arithmetic operations
        while True:
            if self.match("KEYWORD", "AN"):
                # Skip AN keyword and continue parsing
                continue
                
            elif self.match("KEYWORD", "SUM OF"):
                if not self.parse_operand():
                    self.error("Expected first operand after SUM OF")
                operand1 = self.it
                
                if not self.match("KEYWORD", "AN"):
                    self.error("Expected AN keyword")
                    
                if not self.parse_operand():
                    self.error("Expected second operand after AN")
                operand2 = self.it
                
                result = operand1 + operand2
                
            elif self.match("KEYWORD", "DIFF OF"):
                if not self.parse_operand():
                    self.error("Expected first operand after DIFF OF")
                operand1 = self.it
                
                if not self.match("KEYWORD", "AN"):
                    self.error("Expected AN keyword")
                    
                if not self.parse_operand():
                    self.error("Expected second operand after AN")
                operand2 = self.it
                
                result = operand1 - operand2
                
            # Add other arithmetic operations similarly
            else:
                break

        self.it = result
        return True

    def parse_operand(self):
        """Parse a single operand in an expression."""
        if self.match("VARIABLE_IDENTIFIER"):
            var_name = self.tokens[self.current - 1]["value"]
            if var_name not in self.symbol_table:
                self.error(f"Variable '{var_name}' not defined")
            self.it = self.symbol_table[var_name]
            return True
            
        if self.match("NUMBR_LITERAL"):
            self.it = int(self.tokens[self.current - 1]["value"])
            return True
            
        if self.match("NUMBAR_LITERAL"):
            self.it = float(self.tokens[self.current - 1]["value"])
            return True
            
        if self.match("YARN_LITERAL"):
            self.it = self.tokens[self.current - 1]["value"]
            return True
            
        if self.match("TROOF_LITERAL"):
            self.it = self.tokens[self.current - 1]["value"] == "WIN"
            return True

        return False

    def execute_parse():
        # Disable the Execute button to prevent multiple clicks
        execute_button.config(state=tk.DISABLED)

        # Clear previous symbol table and interpreted output
        display_symbols(clear=True)
        display_interpreted(clear=True)

        def run_parser():
            try:
                # Start parse.py as a subprocess
                process = subprocess.Popen(
                    ['python', 'parse.py'],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True
                )

                stdout, stderr = process.communicate()

                if process.returncode != 0:
                    messagebox.showerror("Parsing Failed", stderr or "An unknown error occurred.")
                    return

                # After successful parsing, display symbol table and interpreted output
                display_symbols()
                display_interpreted()
                messagebox.showinfo("Success", "Code ran successfully.")

            except Exception as e:
                messagebox.showerror("Error", str(e))
            finally:
                execute_button.config(state=tk.NORMAL)

        # Run the parser in a separate thread to keep the GUI responsive
        threading.Thread(target=run_parser, daemon=True).start()

    def parse_smoosh(self):
        result = ""
        while True:
            if not self.parse_expression():
                self.error("Expected expression in SMOOSH")
            result += str(self.it)
            if not self.match("KEYWORD", "AN"):
                break
        self.it = result
        return True
        
        def parse_print_list(self):
            """Parse a list of values or expressions: <expr> (+ <expr>)*."""
            result = []  # To store concatenated parts

            
            # First, parse the initial expression
            if not self.parse_expression() :
                self.error("Expected an expression or value after 'VISIBLE'")
            result.append(str(self.it))  # Add the result of the expression

            
            # Handle concatenation using '+' or 'AN'
            while self.match("CONCAT_OPERATOR", "+") or self.match("KEYWORD", "AN"):
                if not self.parse_expression():  # Parse the next expression
                    self.error("Expected an expression after '+' or 'AN'")
                result.append(str(self.it))  # Append the result as a string

            # Concatenate all parts into a single string and store in IT
            self.it = "".join(result)
            # print (self.it)

    def parse_inline_comment(self):
        """Parse an optional inline comment: BTW <text>."""
        self.match("COMMENT")  # Simply consume the COMMENT token if present

    def parse_wazzup(self):
        """Parse the WAZZUP block: WAZZUP ... BUHBYE."""
        if not self.match("KEYWORD", "WAZZUP"):
            self.error("Expected 'WAZZUP' after 'HAI'")

        self.inside_wazzup = True  # Enter WAZZUP block

        while not self.match("KEYWORD", "BUHBYE"):
            if not self.peek():
                self.error("Unterminated 'WAZZUP' block. Expected 'BUHBYE'")
            self.parse_i_has_a()  # Parse variable declarations only

        self.inside_wazzup = False  # Exit WAZZUP block

    def parse_visible(self):
        """Parse a VISIBLE statement."""
        if not self.match("KEYWORD", "VISIBLE"):
            self.error("Expected 'VISIBLE' for print statement")
        if not self.parse_expression():
            self.error("Expected an expression after 'VISIBLE'")
        self.output.append(str(self.it))

    def parse_multiline_comment(self):
        """Parse a multiline comment: OBTW ... TLDR."""
        if not self.match("MULTILINE_COMMENT_START", "OBTW"):
            self.error("Expected 'OBTW' to start a multiline comment")
        
        # Ensure there's no other token after OBTW on the same line
        if self.peek() and self.peek()["type"] != "MULTILINE_COMMENT_END":
            self.error("Invalid token after 'OBTW'. It should be the only token on the line.")
        

        # Now, we expect the next token to be 'TLDR' on a new line
        if not self.match("MULTILINE_COMMENT_END", "TLDR"):
            self.error("Expected 'TLDR' after 'OBTW'")

    def parse_i_has_a(self):
        """Parse the 'I HAS A' statement."""
        if not self.match("KEYWORD", "I HAS A"):
            self.error("Expected 'I HAS A' to declare a variable")
        varident = self.match("VARIABLE_IDENTIFIER")
        if not varident:
            self.error("Expected a variable identifier after 'I HAS A'")
        var_name = varident["value"]
        var_value = None
        if self.match("KEYWORD", "ITZ"):
            if not self.parse_expression():
                self.error("Expected an expression after 'ITZ'")
            var_value = self.it
        self.variables[var_name] = var_value
        self.symbol_table[var_name] = var_value

    def parse_loop(self):
        """Parse a loop: IM IN YR <label> <operation> YR <variable> [TIL/WILE <condition>] ... IM OUTTA YR <label>."""
        if not self.match("KEYWORD", "IM IN YR"):
            self.error("Expected 'IM IN YR' to start a loop")

        # Parse the loop name (label)
        loopname_token = self.match("VARIABLE_IDENTIFIER")
        if not loopname_token:
            self.error("Expected a loop name (variable identifier) after 'IM IN YR'")
        loopname = loopname_token["value"]

        # Parse the operation (UPPIN or NERFIN)
        operation = self.match("KEYWORD")  # Look for the operation (UPPIN or NERFIN)
        if not operation or operation["value"] not in ["UPPIN", "NERFIN"]:
            self.error("Expected 'UPPIN' or 'NERFIN' after loop name")

        # Expect 'YR' after the operation (between the operation and the variable)
        if not self.match("KEYWORD", "YR"):
            self.error("Expected 'YR' after operation to specify the variable")

        # Parse the loop variable (variable to modify)
        var_token = self.match("VARIABLE_IDENTIFIER")
        if not var_token:
            self.error("Expected a variable after 'YR'")

        # Optional: Parse the loop condition type (TIL/WILE)
        condition_type = None
        if self.match("KEYWORD", "TIL"):
            condition_type = "TIL"
        elif self.match("KEYWORD", "WILE"):
            condition_type = "WILE"

        # Parse the loop condition expression (if TIL or WILE)
        if condition_type:
            if not self.parse_expression():
                self.error(f"Expected an expression after '{condition_type}' in loop condition")

        # Loop execution logic: Just loop through the body for now
        self.parse_statements()  # Parse the body of the loop

        # Ensure the loop ends with IM OUTTA YR <loopname>
        if not self.match("KEYWORD", "IM OUTTA YR"):
            self.error("Expected 'IM OUTTA YR' to end the loop")
        if not self.match("VARIABLE_IDENTIFIER", loopname):
            self.error(f"Expected loop name '{loopname}' after 'IM OUTTA YR'")

    def parse_orly(self):
        """Parse an if-then statement: O RLY? YA RLY ... MEBBE ... NO WAI ... OIC."""
        if not self.match("KEYWORD", "O RLY?"):
            self.error("Expected 'O RLY?' to start the block")

        executed = False  # Track whether any block has executed

        # YA RLY block (if-clause)
        if self.match("KEYWORD", "YA RLY"):
            if self.it == "WIN":
                self.parse_statements()  # Execute true block
                executed = True
            else:
                self.skip_block()  # Skip true block if IT is not WIN

        # MEBBE blocks (else-if clauses)
        while self.match("KEYWORD", "MEBBE"):
            if executed:
                self.skip_block()  # Skip this block since a previous block executed
            else:
                # Evaluate the condition for MEBBE
                if not self.parse_expression():
                    self.error("Expected an expression after 'MEBBE'")
                if self.it == "WIN":
                    self.parse_statements()  # Execute this block if condition is true
                    executed = True
                else:
                    self.skip_block()  # Skip this block if condition is false

        # NO WAI block (else-clause)
        if self.match("KEYWORD", "NO WAI"):
            if not executed:  # Only execute if no previous block executed
                self.parse_statements()
            else:
                self.skip_block()  # Skip else block if a previous block executed

        # Ensure the block ends with OIC (closing the O RLY? block)
        if not self.match("KEYWORD", "OIC"):
            self.error("Expected 'OIC' to close 'O RLY?' block")

    def parse_wtf(self):
        """Parse the WTF? block (switch-case statement) with OMG, OMGWTF, and OIC."""
        if not self.match("KEYWORD", "WTF?"):
            self.error("Expected 'WTF?' to start switch-case block.")

        # Store the value of IT (the value to compare against)
        wtf_value = self.it

        case_matched = False
        while self.match("KEYWORD", "OMG"):
            case_value = self.parse_expression()  # Expecting a literal after 'OMG'
            
            # Compare the case value with IT
            if case_value == wtf_value:
                # If it matches, execute the block under this case
                case_matched = True
                self.parse_statements()  # Parse the code block under the matched case
                if self.match("KEYWORD", "GTFO"):  # If GTFO is found, break out of the switch-case
                    break
            else:
                self.skip_block()  # Skip the block if case doesn't match

        # Handle the default case (OMGWTF)
        if not case_matched and self.match("KEYWORD", "OMGWTF"):
            self.parse_statements()  # Execute default case block
            if self.match("KEYWORD", "GTFO"):  # End the default case block
                return

        # Now we expect OIC to close the switch-case block
        if not self.match("KEYWORD", "OIC"):
            self.error("Expected 'OIC' to close switch-case block.")
            
# [parse.py](parse.py#L612)
    def parse_gimmeh(self):
        """Parse the GIMMEH statement: GIMMEH <varident>."""
        if not self.match("KEYWORD", "GIMMEH"):
            self.error("Expected 'GIMMEH' to read input")

        # Parse the variable identifier
        varident = self.match("VARIABLE_IDENTIFIER")
        if not varident:
            self.error("Expected a variable identifier after 'GIMMEH'")

        var_name = varident["value"]

        # Prompt the user for input via GUI dialog
        user_input = get_user_input(var_name)

        # Assign the input to the variable and symbol table
        self.variables[var_name] = self.cast_input(var_name, user_input)
        self.symbol_table[var_name] = self.variables[var_name]

    def cast_input(self, var_name, user_input):
        """Cast the input to the appropriate type based on existing variable type."""
        existing_value = self.symbol_table.get(var_name)
        if isinstance(existing_value, int):
            try:
                return int(user_input)
            except ValueError:
                self.error(f"Invalid integer input for variable '{var_name}'. Please enter a valid number.")
        elif isinstance(existing_value, float):
            try:
                return float(user_input)
            except ValueError:
                self.error(f"Invalid float input for variable '{var_name}'. Please enter a valid decimal number.")
        elif isinstance(existing_value, bool):
            if user_input.upper() == "WIN":
                return True
            elif user_input.upper() == "FAIL":
                return False
            else:
                self.error(f"Invalid TROOF input for variable '{var_name}'. Use 'WIN' or 'FAIL'.")
        else:
            return user_input  # Treat as string (YARN)

    def skip_block(self):
        """Skip over a block until encountering a terminating keyword."""
        while self.peek():
            token = self.peek()
            if token["value"] in ["OIC", "NO WAI", "KTHXBYE"]:
                return  # Exit on block terminators
            self.consume()

    def parse_assignment(self, varident):
        """Parse an assignment: varident R <expression>."""
        if not self.match("KEYWORD", "R"):
            self.error("Expected 'R' for assignment")
        if not self.parse_expression():
            self.error("Expected an expression after 'R'")
        var_name = varident["value"]
        var_value = self.it
        self.variables[var_name] = var_value
        self.symbol_table[var_name] = var_value
        return self.it
        
    def parse_is_now_a(self, varident):
        """Parse 'IS NOW A' type casting: varident IS NOW A <type>."""
        if not varident:
            self.error("Expected a variable identifier before 'IS NOW A'")

        if not self.match("KEYWORD", "IS NOW A"):
            self.error("Expected 'IS NOW A' for typecasting")

        # Now, we expect a type (NUMBR, NUMBAR, YARN, TROOF, etc.)
        type_ = self.match("KEYWORD")
        if not type_:
            self.error("Expected a type after 'IS NOW A'")

        # Handle the typecasting logic based on the type
        if type_:
            # Change the type of the variable without changing the value
            if type_["value"] == "NUMBR":
                self.variables[varident["value"]] = {"value": self.variables.get(varident["value"], 0), "type": "NUMBR"}
            elif type_["value"] == "NUMBAR":
                self.variables[varident["value"]] = {"value": self.variables.get(varident["value"], 0), "type": "NUMBAR"}
            elif type_["value"] == "YARN":
                self.variables[varident["value"]] = {"value": str(self.variables.get(varident["value"], "")), "type": "YARN"}
            elif type_["value"] == "TROOF":
                self.variables[varident["value"]] = {"value": bool(self.variables.get(varident["value"], False)), "type": "TROOF"}
            else:
                self.error(f"Unsupported type '{type_['value']}' after 'IS NOW A'")
        else:
            self.error(f"Unsupported type '{type_['value']}' after 'IS NOW A'")

    def parse_maek(self):
        """Parse explicit typecasting with 'MAEK A': MAEK A varident <type>."""
        varident = self.match("VARIABLE_IDENTIFIER")
        if not varident:
            self.error("Expected a variable identifier after 'MAEK A'")

        # Parse the target type (NUMBR, NUMBAR, YARN, etc.)
        type_ = self.match("KEYWORD")

        # Typecast the variable and return the result in IT
        if type_:
            # Change the type of the variable without changing the value
            if type_["value"] == "NUMBR":
                self.variables[varident["value"]] = {"value": self.variables.get(varident["value"], 0), "type": "NUMBR"}
            elif type_["value"] == "NUMBAR":
                self.variables[varident["value"]] = {"value": self.variables.get(varident["value"], 0), "type": "NUMBAR"}
            elif type_["value"] == "YARN":
                self.variables[varident["value"]] = {"value": str(self.variables.get(varident["value"], "")), "type": "YARN"}
            elif type_["value"] == "TROOF":
                self.variables[varident["value"]] = self.cast_to_troof(self.variables.get(varident["value"], 0))
        else:
            self.error(f"Unsupported type '{type_['value']}' after 'MAEK A'")

        return self.it
    def cast_to_troof(self, value):
        """Cast any value to a TROOF."""
        if value == 0 or value == 0.0 or value == "":  # Empty string or zero
            return False  # FAIL
        else:
            return True  # WIN
    def parse_function_definition(self):
        """Parse a function definition: HOW IZ I <function name> [YR <parameters>] ... IF U SAY SO."""
        if not self.match("KEYWORD", "HOW IZ I"):
            self.error("Expected 'HOW IZ I' to start a function definition")

        # Parse the function name
        func_name = self.match("VARIABLE_IDENTIFIER")
        if not func_name:
            self.error("Expected a function name after 'HOW IZ I'")

        func_name = func_name["value"]

        # Parse the parameter list
        parameters = []
        if self.match("KEYWORD", "YR"):
            while True:
                param = self.match("VARIABLE_IDENTIFIER")
                if not param:
                    self.error("Expected a parameter name after 'YR'")
                parameters.append(param["value"])

                # Check for "AN YR" sequence
                if self.match("KEYWORD", "AN"):
                    if not self.match("KEYWORD", "YR"):
                        self.error("Expected 'YR' after 'AN' for additional parameters")
                else:
                    break  # No more parameters

        # Temporarily save the current variables for the function scope
        previous_variables = self.variables.copy()  # Save current variable state
        self.variables = {param: None for param in parameters}  # Initialize function parameters as variables

        # Parse the function body
        body_statements = []
        while not self.match("KEYWORD", "IF U SAY SO"):
            if not self.peek():
                self.error("Unterminated function body; expected 'IF U SAY SO'")

            token = self.peek()
            if token["value"] == "GTFO":
                self.consume()  # Consume GTFO
                body_statements.append({"type": "EXIT"})  # Add exit statement
            elif token["value"] == "FOUND YR":
                self.consume()  # Consume FOUND YR
                if not self.parse_expression():
                    self.error("Expected an expression after 'FOUND YR'")
                body_statements.append({"type": "RETURN", "value": self.it})  # Add return statement
            else:
                body_statements.append(self.parse_statements())  # Parse regular statements

        # Restore the global variable state
        self.variables = previous_variables

        # Save the function in the function table
        self.functions[func_name] = {
            "parameters": parameters,
            "body": body_statements
        }
        print(self.functions)
        print(f"Function '{func_name}' defined with parameters {parameters}")

    def execute_function(self, func_name, func_body, local_variables):
        """Execute a function body with local variables."""
        if func_name not in self.functions:
                self.error(f"Function '{func_name}' not defined")
        # Store the local variables in the parser's scope
        self.variables.update(local_variables)
        
        # Save the current state of IT to handle return values properly
        previous_it = self.it

        # Execute the function body
        for statement in func_body:
            if statement is None:
                continue
            # For each statement in the function body, execute it
            if statement["type"] == "RETURN":
                self.it = statement["value"]  # Set the return value to IT
                break  # Exit the function
            elif statement["type"] == "EXIT":
                self.it = "NOOB"  # No return value in case of GTFO
                break  # Exit the function
            else:
                self.parse_statements()  # Execute other statements inside the function

            # Handle return statement (FOUND YR <expression>)
        if self.match("KEYWORD", "FOUND YR"):
            self.parse_expression()  # Parse the return expression
            self.it = self.it  # Store the result in IT

        # Handle GTFO (no return value)
        elif self.match("KEYWORD", "GTFO"):
            self.it = "NOOB"  # No return value in case of GTFO
        # If no return is found, set the IT to NOOB
        if self.it is None:
            self.it = "NOOB"
        
        # Restore IT after function execution
        self.it = previous_it

    def parse_function_call(self):
        """Parse and execute a function call: I IZ <function_name> [YR <arg1> AN YR <arg2> ...] MKAY."""
        if not self.match("KEYWORD", "I IZ"):
            self.error("Expected 'I IZ' to start a function call")

        # Parse the function name
        func_name = self.match("VARIABLE_IDENTIFIER")
        if not func_name:
            self.error("Expected a function name after 'I IZ'")

        func_name = func_name["value"]

        # Parse the arguments
        arguments = []
        if self.match("KEYWORD", "YR"):
            while True:
                if not self.parse_expression():  # Parse the argument as an expression
                    self.error("Expected an argument expression after 'YR'")
                arguments.append(self.it)  # Store the evaluated argument

                # Match "AN YR" for additional arguments
                if self.match("KEYWORD", "AN"):  # Match "AN"
                    if not self.match("KEYWORD", "YR"):
                        self.error("Expected 'YR' after 'AN' for additional arguments")
                else:
                    break  # Stop if no more arguments

        # Optional function call ends with MKAY
        if not self.match("KEYWORD", "MKAY"):
            # Check if the next token indicates the start of a new statement or block terminator
            next_token = self.peek()
            if next_token and next_token["value"] not in ["VISIBLE", "I HAS A", "IM OUTTA YR", "KTHXBYE"]:
                self.error("Unexpected token after function call. Expected 'MKAY' or a valid statement.")

        # If prefer natin na walang gawin yung MKAY, tapos okay lang na i-call yung function call anywhere, uncomment yung nasa baba
        # self.match("KEYWORD", "MKAY")  # If MKAY is present, consume it


        # Look up the function in the function table
        if func_name not in self.functions:
            self.error(f"Function '{func_name}' not defined")

        # Get the function definition
        func_def = self.functions[func_name]
        func_params = func_def["parameters"]
        func_body = func_def["body"]

        # Check argument count
        if len(arguments) != len(func_params):
            self.error(f"Function '{func_name}' expects {len(func_params)} arguments but got {len(arguments)}")

        # Create a local variable scope for the function
        local_variables = {param: value for param, value in zip(func_params, arguments)}

        # Execute the function
        self.execute_function(func_name, func_body, local_variables)
        
        return self.it
    
    def parse_statements(self):
        """Parse a sequence of statements within a block."""
        while self.peek():
            token = self.peek()
            if token["type"] == "MULTILINE_COMMENT_START" and token["value"] == "OBTW":
                self.parse_multiline_comment()  # Handle the multiline comment
                continue  # Skip to the next token after consuming the comment
            # Handle function calls
            if token["value"] == "I IZ":
                self.parse_function_call()
                continue  # Continue after parsing the function call
            if token["value"] in ["OIC", "NO WAI", "MEBBE", "IM OUTTA YR", "KTHXBYE", "IF U SAY SO", "GTFO"]:
                return  # Exit on block terminators
            elif self.match("KEYWORD", "VISIBLE"):
                self.current -= 1  # Allow parse_visible to handle it
                self.parse_visible()
            elif self.match("KEYWORD", "I HAS A"):
                self.current -= 1  # Allow parse_i_has_a to handle it
                self.parse_i_has_a()
            elif self.match("KEYWORD", "O RLY?"):
                self.current -= 1  # Allow nested conditional blocks
                self.parse_orly()
            elif self.match("KEYWORD", "WTF?"):
                self.current -= 1
                self.parse_wtf()
            elif self.match("KEYWORD", "IM IN YR"):
                self.current -= 1  # Allow nested loops
                self.parse_loop()
            elif self.match("KEYWORD", "WAZZUP"):
                self.current -= 1  # Allow nested WAZZUP blocks
                self.parse_wazzup()
            elif self.match("KEYWORD", "GIMMEH"):
                self.current -= 1   
                self.parse_gimmeh()
            elif self.match("KEYWORD", "SMOOSH"):
                self.current -= 1
                self.parse_smoosh()
            elif self.match("VARIABLE_IDENTIFIER"):
                varident = self.tokens[self.current - 1]  # Store the current variable identifier
                print(f"Variable identifier found: {varident}")  # Debugging

                if self.peek()["value"] == "R":  # Check for 'R' without consuming
                    print(f"'R' found after variable '{varident['value']}'")  # Debugging
                    self.parse_assignment(varident)  # Proceed with assignment parsing
                elif self.peek()["value"] == "IS NOW A":  # If it's a type-casting operation
                    self.parse_is_now_a(varident)  # Pass the variable identifier to handle typecasting
                else:  # Otherwise, treat it as part of an expression
                    self.current -= 1  # Roll back to allow parse_expression to handle it
                    self.parse_expression()
                # Handle typecasting (if 'IS NOW A' is found)
            elif self.match("KEYWORD", "MAEK A"):
                self.current -= 1  
                self.parse_maek()
            elif self.match("KEYWORD", "BOTH SAEM") or self.match("KEYWORD", "DIFFRINT"):
                self.current -= 1  # Allow parse_expression to handle it
                self.parse_expression()
            elif self.match("KEYWORD", "HOW IZ I"):
                self.current -= 1 
                self.parse_function_definition()
            else:
                self.error(f"Unexpected token inside block: {token}")

    def parse_program_structure(self):
        """Parse the program structure with support for comments and valid statements."""
        if not self.match("KEYWORD", "HAI"):
            self.error("Expected 'HAI' at the start of the program")

        while self.match("KEYWORD", "HOW IZ I"):  # Function declarations can appear before WAZZUP
            self.parse_function_definition()      # Handle function definition

        # Parse the WAZZUP block for variable declarations
        if self.peek() and self.match("KEYWORD", "WAZZUP"):
            self.current -= 1  # Roll back to parse the WAZZUP block
            self.parse_wazzup()
        else:
            self.error("Expected 'WAZZUP' after 'HAI' for variable declarations")

        while self.peek():
            if self.match("KEYWORD", "KTHXBYE"):
                # Optionally retain these lines for confirmation
                # print("PARSE_SUCCESS", flush=True)
                # print("Symbol Table Updated.", flush=True)
                return
            self.parse_statements()  # Parse the rest of the statements
    
    def interpret(self):
        """Start the interpretation and write outputs."""
        self.parse_program_structure()
        # Write the symbol table to symbols.txt
        with open('symbols.txt', 'w') as sym_file:
            for var_name, var_value in self.symbol_table.items():
                sym_file.write(f'{var_name}: {var_value}\n')
        # Write the output to interpreted.txt
        with open('interpreted.txt', 'w') as out_file:
            for line in self.output:
                out_file.write(f'{line}\n')
        # Optionally signal successful parsing
        # print("PARSE_SUCCESS", flush=True)
        # print("Symbol Table Updated.", flush=True)

def get_user_input(var_name):
    """Prompt the user for input using a GUI dialog."""
    try:
        root = tk.Tk()
        root.withdraw()  # Hide the main window
        user_input = simpledialog.askstring(title="Input Required", prompt=f"Enter value for '{var_name}':")
        root.destroy()
        return user_input if user_input is not None else ""
    except Exception as e:
        self.error(f"Failed to get input for variable '{var_name}': {e}")

def main(input_callback=None):
    tokens = read_tokens()

    if not tokens:
        print("PARSING FAILED: No tokens found.", flush=True)
        with open("parsed.txt", "w") as output_file:
            output_file.write("PARSING FAILED: No tokens found.\n")
        return

    parser = Parser(tokens, input_callback=input_callback)

    try:
        parser.interpret()
        print("PARSE_SUCCESS", flush=True)
        print("Symbol Table Updated.", flush=True)
    except SyntaxError as e:
        with open("parsed.txt", "w") as output_file:
            output_file.write(f"PARSING FAILED: {e}\n")
        print(f"PARSING FAILED: {e}", flush=True)
    except Exception as e:
        with open("parsed.txt", "w") as output_file:
            output_file.write(f"PARSING FAILED: {e}\n")
        print(f"PARSING FAILED: {e}", flush=True)

if __name__ == "__main__":
    main()
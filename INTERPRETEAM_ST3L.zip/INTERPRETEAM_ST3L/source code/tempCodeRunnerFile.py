# main.py

import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog
from tkinter import ttk
import subprocess
import json
import os
import shutil
import threading
import queue

# Initialize the communication queues globally
input_requests_queue = queue.Queue()
input_responses_queue = queue.Queue()

# Variable to track file upload status
file_uploaded = False

# Button hover effects
def on_enter(e):
    e.widget['bg'] = '#0069d9'

def on_leave(e):
    e.widget['bg'] = '#4285F4'

def upload_file():
    global file_uploaded, file_name_display, execute_button, code_text, tokens_table, refresh_button
    file_path = filedialog.askopenfilename(title="Select a .lol file", filetypes=(("LOL files", "*.lol"),))
    if file_path:
        file_uploaded = True
        file_name = os.path.basename(file_path)  # Get only the filename
        file_name_display.config(text=file_name)  # Display only the filename
        # Enable the Execute and Refresh buttons
        execute_button.config(state=tk.NORMAL)
        refresh_button.config(state=tk.NORMAL)
        # Display the code in the text widget
        with open(file_path, 'r') as f:
            code = f.read()
        code_text.delete(1.0, tk.END)
        code_text.insert(tk.END, code)
        # Copy the uploaded file to where parse.py expects it
        shutil.copyfile(file_path, 'input.lol')
        # Run the tokenizer and display tokens
        run_tokenizer()
        display_tokens()

def run_tokenizer():
    subprocess.run(['python', 'lexical.py', 'input.lol'])

def display_tokens():
    global tokens_table
    # Clear the tokens table
    for item in tokens_table.get_children():
        tokens_table.delete(item)
    # Read the tokens from lexical.txt and display them
    if os.path.exists('lexical.txt'):
        with open('lexical.txt', 'r') as f:
            lines = f.readlines()
            for line in lines:
                try:
                    token = json.loads(line)
                    lexeme = token.get('value', '')
                    token_type = token.get('type', '')
                    tokens_table.insert('', 'end', values=(lexeme, token_type))
                except json.JSONDecodeError:
                    continue  # Skip malformed lines

def execute_parse():
    # Disable the Execute button to prevent multiple clicks
    execute_button.config(state=tk.DISABLED)

    # Clear previous symbol table and interpreted output
    display_symbols(clear=True)
    display_interpreted(clear=True)

    def run_parser():
        try:
            # Start parse.py as a subprocess with pipes
            process = subprocess.Popen(
                ['python', 'parse.py'],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1
            )

            while True:
                line = process.stdout.readline()
                if not line:
                    break  # End of output

                line = line.strip()
                print(f"parse.py output: {line}")  # Debugging print

                if line.startswith("REQUEST_INPUT:"):
                    var_name = line.split(":", 1)[1]
                    # Send the input request to the main thread
                    input_requests_queue.put(var_name)
                    # Wait for the user input from the main thread
                    user_input = input_responses_queue.get()
                    if user_input is None:
                        user_input = ""  # Handle cancellation
                    # Send the input back to parse.py
                    process.stdin.write(user_input + '\n')
                    process.stdin.flush()
                elif line == "PARSE_SUCCESS":
                    break
                else:
                    # Optionally handle other outputs or logs from parse.py
                    pass

            process.stdout.close()
            process.wait()

            # Capture stderr
            stderr = process.stderr.read()
            if stderr:
                messagebox.showerror("Parsing Failed", stderr)
                return

            if os.path.exists('parsed.txt'):
                with open('parsed.txt', 'r') as f:
                    parsed_content = f.read()
                if "PARSING FAILED" in parsed_content:
                    messagebox.showerror("Parsing Failed", parsed_content)
                    return

            # After successful parsing, display symbol table and interpreted output
            display_symbols()
            display_interpreted()
            messagebox.showinfo("Success", "Code ran successfully.")

        except Exception as e:
            messagebox.showerror("Error", str(e))
        finally:
            execute_button.config(state=tk.NORMAL)

    # Start the parser in a separate thread to keep the GUI responsive
    threading.Thread(target=run_parser, daemon=True).start()

def display_symbols(clear=False):
    global symbols_table
    # Clear the symbols table if requested
    if clear:
        for item in symbols_table.get_children():
            symbols_table.delete(item)
        return

    # Populate the symbols table from 'symbols.txt'
    if os.path.exists('symbols.txt'):
        with open('symbols.txt', 'r') as f:
            lines = f.readlines()
            for line in lines:
                parts = line.strip().split(':', 1)
                if len(parts) == 2:
                    var_name = parts[0].strip()
                    var_value = parts[1].strip()
                    symbols_table.insert('', 'end', values=(var_name, var_value))

def display_interpreted(clear=False):
    global interpreted_text
    if clear:
        interpreted_text.delete(1.0, tk.END)
        return

    # Read interpreted.txt and display its content
    if os.path.exists('interpreted.txt'):
        with open('interpreted.txt', 'r') as f:
            content = f.read()
            interpreted_text.delete(1.0, tk.END)
            interpreted_text.insert(tk.END, content)

def reset_app():
    global file_uploaded, file_name_display, execute_button, code_text, tokens_table, symbols_table, refresh_button
    file_uploaded = False
    code_text.delete(1.0, tk.END)
    execute_button.config(state=tk.DISABLED)
    refresh_button.config(state=tk.DISABLED)
    file_name_display.config(text="No file selected")
    for item in tokens_table.get_children():
        tokens_table.delete(item)
    for item in symbols_table.get_children():
        symbols_table.delete(item)
    interpreted_text.delete(1.0, tk.END)

# Create the main window
root = tk.Tk()
root.title("LOLCODE Interpreter")
root.geometry("1200x800")
root.configure(bg="#f5f5f5")

# Header Label
header_label = tk.Label(root, text="LOLCODE Interpreter", bg="#f5f5f5", fg="#20232a", font=("Arial", 20, "bold"))
header_label.pack(pady=10)

# Create a frame for the file upload and execute buttons
file_frame = tk.Frame(root, bg="#f5f5f5")
file_frame.pack(pady=10)

# File upload button
upload_button = tk.Button(
    file_frame,
    text="Upload .lol File",
    command=upload_file,
    bg="#4285F4",
    fg="white",
    font=("Arial", 12, "bold"),
    relief="flat"
)
upload_button.pack(side=tk.LEFT, padx=10)
upload_button.bind("<Enter>", on_enter)
upload_button.bind("<Leave>", on_leave)

file_name_display = tk.Label(
    file_frame,
    text="No file selected",
    bg="#f5f5f5",
    fg="#20232a",
    font=("Arial", 12)
)
file_name_display.pack(side=tk.LEFT, padx=10)

# Execute button
execute_button = tk.Button(
    file_frame,
    text="Run Code",
    command=execute_parse,
    bg="#34A853",
    fg="white",
    font=("Arial", 12, "bold"),
    relief="flat",
    state=tk.DISABLED
)
execute_button.pack(side=tk.LEFT, padx=10)

# Refresh button
refresh_button = tk.Button(
    file_frame,
    text="Refresh",
    command=reset_app,
    bg="#fbbc05",
    fg="white",
    font=("Arial", 12, "bold"),
    relief="flat",
    state=tk.DISABLED
)
refresh_button.pack(side=tk.LEFT, padx=10)

# Main content frame to hold code, tokens, and symbols
main_frame = tk.Frame(root, bg="#f5f5f5")
main_frame.pack(expand=True, fill=tk.BOTH, padx=10, pady=10)

# Configure grid columns for equal weight
main_frame.columnconfigure(0, weight=1)
main_frame.columnconfigure(1, weight=1)
main_frame.columnconfigure(2, weight=1)

# Code frame
code_frame = tk.Frame(main_frame)
code_frame.grid(row=0, column=0, sticky='nsew', padx=5, pady=5)

# Code label and text widget
code_label = tk.Label(code_frame, text="Code:", font=("Arial", 14, "bold"))
code_label.pack()
code_text = tk.Text(code_frame, wrap=tk.WORD, font=("Courier", 12))
code_text.pack(expand=True, fill=tk.BOTH)

# Add scrollbar to code_text
code_scrollbar = tk.Scrollbar(code_frame, command=code_text.yview)
code_scrollbar.pack(side=tk.RIGHT, fill='y')
code_text.configure(yscrollcommand=code_scrollbar.set)

# Tokens frame
tokens_frame = tk.Frame(main_frame)
tokens_frame.grid(row=0, column=1, sticky='nsew', padx=5, pady=5)

# Tokens label and table
tokens_label = tk.Label(tokens_frame, text="Tokens:", font=("Arial", 14, "bold"))
tokens_label.pack()
tokens_table = ttk.Treeview(tokens_frame, columns=("Lexeme", "Type"), show='headings')
tokens_table.heading("Lexeme", text="Lexeme")
tokens_table.heading("Type", text="Type")
tokens_table.pack(expand=True, fill=tk.BOTH)

# Add scrollbar to tokens_table
tokens_scrollbar = ttk.Scrollbar(tokens_frame, orient=tk.VERTICAL, command=tokens_table.yview)
tokens_scrollbar.pack(side=tk.RIGHT, fill='y')
tokens_table.configure(yscrollcommand=tokens_scrollbar.set)

# Symbols frame
symbols_frame = tk.Frame(main_frame)
symbols_frame.grid(row=0, column=2, sticky='nsew', padx=5, pady=5)

# Symbols label and table
symbols_label = tk.Label(symbols_frame, text="Symbol Table:", font=("Arial", 14, "bold"))
symbols_label.pack()
symbols_table = ttk.Treeview(symbols_frame, columns=("Variable", "Value"), show='headings')
symbols_table.heading("Variable", text="Variable")
symbols_table.heading("Value", text="Value")
symbols_table.pack(expand=True, fill=tk.BOTH)

# Add scrollbar to symbols_table
symbols_scrollbar = ttk.Scrollbar(symbols_frame, orient=tk.VERTICAL, command=symbols_table.yview)
symbols_scrollbar.pack(side=tk.RIGHT, fill='y')
symbols_table.configure(yscrollcommand=symbols_scrollbar.set)

# Allow frames to expand
for frame in [code_frame, tokens_frame, symbols_frame]:
    frame.rowconfigure(0, weight=1)
    frame.columnconfigure(0, weight=1)

# Interpreted Output Frame
output_frame = ttk.LabelFrame(root, text="Interpreted Output:", padding=(10, 5))
output_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

interpreted_text = tk.Text(output_frame, font=("Courier", 12), wrap=tk.WORD, height=10)
interpreted_text.pack(expand=True, fill=tk.BOTH)

interpreted_scrollbar = ttk.Scrollbar(output_frame, orient=tk.VERTICAL, command=interpreted_text.yview)
interpreted_scrollbar.pack(side=tk.RIGHT, fill='y')
interpreted_text.configure(yscrollcommand=interpreted_scrollbar.set)

# Reset Button Frame
reset_frame = tk.Frame(root, bg="#f5f5f5")
reset_frame.pack(pady=10)

reset_button = tk.Button(
    reset_frame,
    text="Reset",
    command=reset_app,
    bg="#EA4335",
    fg="white",
    font=("Arial", 12, "bold"),
    relief="flat"
)
reset_button.pack()

# Function to handle input requests from the parser thread
def handle_input_requests():
    try:
        var_name = input_requests_queue.get_nowait()
        user_input = simpledialog.askstring("Input Required", f"Enter value for '{var_name}':")
        input_responses_queue.put(user_input)
    except queue.Empty:
        pass
    # Continue checking every 100 milliseconds
    root.after(100, handle_input_requests)

# Start handling input requests
handle_input_requests()

# Start the main event loop
root.mainloop()
def read_lexical_file(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()
    return lines

def create_symbol_table(lines):
    symbol_table = {}
    for line in lines:
        if line.startswith("I HAS A"):
            parts = line.split("ITZ")
            var_name = parts[0].strip().split()[-1]
            var_value = parts[1].strip().strip('"') if len(parts) > 1 else None
            if var_value is not None:
                if var_value.isdigit():
                    var_value = int(var_value)
                elif var_value.replace('.', '', 1).isdigit():
                    var_value = float(var_value)
                elif var_value in ["WIN", "FAIL"]:
                    var_value = var_value == "WIN"
            symbol_table[var_name] = var_value
        elif line.startswith("VISIBLE"):
            parts = line.split("VISIBLE")[1].strip()
            if parts in symbol_table:
                print(symbol_table[parts])
            else:
                print(parts.strip('"'))
    return symbol_table

def main():
    lexical_file_path = 'lexical.txt'
    lines = read_lexical_file(lexical_file_path)
    symbol_table = create_symbol_table(lines)
    print("Symbol Table:")
    for var_name, var_value in symbol_table.items():
        print(f"{var_name}: {var_value}")

if __name__ == "__main__":
    main()